Remplacez les photos exemples par vos images en gardant ces noms :
- couple-hero.jpg (photo de couverture)
- photo-01.jpg
- photo-02.jpg
- photo-03.jpg
- photo-04.jpg
- photo-05.jpg
Conseil : images JPG/WebP compressées, idéalement moins de 500 Ko chacune.
