INVITATION DE MARIAGE — GUIDE RAPIDE

FICHIERS
- index.html : site complet (HTML + CSS + JavaScript dans un seul fichier)
- photos/ : placez vos images dans ce dossier en gardant les noms indiqués dans photos/README.txt

PERSONNALISATION
Ouvrez index.html dans un éditeur de texte (Bloc-notes ou VS Code). Dans le script, en bas du fichier, modifiez l'objet MARIAGE : prénoms, initiales, dateISO, dateAffichee, salle, adresse, ville, dateLimite, hashtag et formulaireRSVP.

IMPORTANT POUR LA CONFIRMATION RSVP
Le bouton doit pointer vers un formulaire réel. Créez un Google Forms, configurez les questions (nom, présence, nombre de personnes, téléphone, allergies si nécessaire), puis copiez son lien dans formulaireRSVP.

PHOTOS
Remplacez les images dans le dossier photos en conservant exactement les noms de fichiers. Les photos doivent être ajoutées avant l'envoi sur GitHub.
